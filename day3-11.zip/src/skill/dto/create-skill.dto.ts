export class CreateSkillDto {}
