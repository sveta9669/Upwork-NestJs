import { Controller, Get, Post, Body, Patch, Param, Delete, HttpStatus } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Request, Res, UseGuards } from '@nestjs/common/decorators';
import { AuthGuard } from '@nestjs/passport';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) { }

  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.create(createUserDto);
  }

  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  applyWork(@Param("id") id: string, @Request() req) {
    console.log(id);
    
    if (req.user?.roles.includes("USER")) {
      return this.userService.applyWork(id, req.user.id)
    } else {
      return "you cannot apply for this work"
    }
  }


  // @Get(':id')
  // findOne(@Param('id') id: string) {
  //   return this.userService.findOneByEmail(id);
  // }


  @UseGuards(AuthGuard('jwt'))
  @Patch()
  async update(@Body() updateUserDto: UpdateUserDto, @Request() req, @Res() res) {
    try {
      const  user =  this.userService.update(req.user.userId, updateUserDto);
      return res.status(HttpStatus.OK).json({
        message: "user updated",
        user
      })
    } catch (err) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        message: "bad request",
        errors: err.message
      })
    }
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userService.remove(id);
  }
}
