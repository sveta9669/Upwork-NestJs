export enum RolesTypes{
    ADMIN='ADMIN',
    USER='USER'
}