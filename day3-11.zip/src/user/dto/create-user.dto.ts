export class CreateUserDto {
    password:string;
    email:string
}
