import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose/dist';
import { Model } from 'mongoose';
import { Work, WorkDocument } from 'src/work/entities/work.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User, UserDocument } from './entities/user.entity';
import { RolesTypes } from './role/enum.role';
import { UserInterface } from './role/user.interface';
import * as bcrypt from 'bcrypt'
@Injectable()
export class UserService {
  // private readonly users = [
  //   {
  //     userId: 1,
  //     username: 'anna',
  //     password: '12345',
  //     roles: [RolesTypes.USER],
  //   },
  //   {
  //     userId: 2,
  //     username: 'andrew',
  //     password: '54321',
  //     roles: [RolesTypes.ADMIN],
  //   },
  // ];
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    @InjectModel(Work.name) private workModel: Model<WorkDocument>
  ) {

  }
  create(createUserDto: CreateUserDto) {
    console.log(createUserDto);
    const us = this.userModel.findOne( { email: createUserDto.email })
    if (!us) {
      return "Change email"
    } else {
      const hash = bcrypt.hashSync(createUserDto.password, 10)
      const user = new this.userModel({ ...createUserDto, password: hash })
      return user.save();
    }

  }
  async findOneByEmail(username: string) {
    return this.userModel.findOne({ email: username });
  }




  findAll() {
    return `This action returns all user`;
  }

  findOne(id: string) {
    return `This action returns a #${id} user`;
  }

  async applyWork(id: string, userId:string) {
      const work = await this.workModel.findById(id)
      console.log(work);
      const workupdate = await this.workModel.findByIdAndUpdate(id, {apply:[...work.apply, userId]})
      return workupdate
  }
  async update(id, updateUserDto: UpdateUserDto) {
    const user = await this.userModel.findByIdAndUpdate(id,updateUserDto)
    return user;
  }
  // async addSkill(){
  //   await
  // }

  remove(id: string) {
    return `This action removes a #${id} user`;
  }
}
