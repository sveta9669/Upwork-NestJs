export const jwtConstants = {
    secret: 'sv',
  };