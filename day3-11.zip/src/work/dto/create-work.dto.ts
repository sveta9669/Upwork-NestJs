export class CreateWorkDto {}
